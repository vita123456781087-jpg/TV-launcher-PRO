package com.example.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Хранилище настроек и список всех пунктов меню настроек.
 * Чтобы добавить новую настройку: допиши строку в OPTS и обработай её в MainActivity.
 */
final class Cfg {

    // ---- ключи настроек ----
    static final String THEME = "theme", ACCENT = "accent", BGSTYLE = "bg_style",
            WAVES = "bg_waves", BGDIM = "bg_dim";
    static final String CLOCK_SHOW = "clock_show", CLOCK_FMT = "clock_fmt",
            CLOCK_SIZE = "clock_size", CLOCK_POS = "clock_pos", CLOCK_FONT = "clock_font",
            CLOCK_DATE = "clock_date";
    static final String TILE_SIZE = "tile_size", TILE_RATIO = "tile_ratio",
            TILE_ROUND = "tile_round", TILE_GAP = "tile_gap", TILE_BANNERS = "tile_banners",
            TILE_LABELS = "tile_labels", TILE_TINT = "tile_tint";
    static final String ROW_POS = "row_pos", ALL_POS = "row_all";
    static final String FOCUS_SCALE = "focus_scale", FOCUS_BORDER = "focus_border",
            FOCUS_ANIM = "focus_anim";
    static final String ALL_COLS = "all_cols", ALL_SORT = "all_sort";

    // ---- цветовые темы: три цвета фона и три цвета волн ----
    static final int[][] THEME_BG = {
            {0xFF080D1C, 0xFF17123D, 0xFF0A2C3C}, // Ночь
            {0xFF04121F, 0xFF06344F, 0xFF0B5C6B}, // Океан
            {0xFF1A0B1E, 0xFF4A1942, 0xFF7A2E2E}, // Закат
            {0xFF06140E, 0xFF0E3B26, 0xFF1D4A2A}, // Лес
            {0xFF1C0A16, 0xFF4A1235, 0xFF2B1250}, // Роза
            {0xFF101214, 0xFF1B1F24, 0xFF262B32}, // Графит
            {0xFF000000, 0xFF000000, 0xFF000000}  // Чёрный
    };
    static final int[][] THEME_WAVE = {
            {0xFF4FD1FF, 0xFF8E6BFF, 0xFF3A8DFF},
            {0xFF5EEAD4, 0xFF38BDF8, 0xFF22D3EE},
            {0xFFFB923C, 0xFFF472B6, 0xFFFACC15},
            {0xFF4ADE80, 0xFFA3E635, 0xFF2DD4BF},
            {0xFFF472B6, 0xFFC084FC, 0xFFFB7185},
            {0xFF94A3B8, 0xFF64748B, 0xFFCBD5E1},
            {0xFF4FD1FF, 0xFF8E6BFF, 0xFF3A8DFF}
    };
    // Голубой, Фиолетовый, Розовый, Оранжевый, Зелёный, Красный, Белый
    static final int[] ACCENTS = {
            0xFF38BDF8, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316, 0xFF22C55E, 0xFFEF4444, 0xFFFFFFFF
    };

    // ---- описание пунктов меню ----
    static final class Opt {
        final String key;
        final String title;
        final int def;
        final String[] labels;

        Opt(String key, String title, int def, String... labels) {
            this.key = key;
            this.title = title;
            this.def = def;
            this.labels = labels;
        }

        boolean isHeader() { return key == null; }
    }

    private static Opt h(String title) { return new Opt(null, title, 0); }

    private static Opt o(String key, String title, int def, String... labels) {
        return new Opt(key, title, def, labels);
    }

    static final Opt[] OPTS = {
            h("ТЕМА И ФОН"),
            o(THEME, "Цветовая тема", 0, "Ночь", "Океан", "Закат", "Лес", "Роза", "Графит", "Чёрный"),
            o(ACCENT, "Акцентный цвет", 0, "Голубой", "Фиолетовый", "Розовый", "Оранжевый", "Зелёный", "Красный", "Белый"),
            o(BGSTYLE, "Фон", 0, "Волны", "Градиент", "Однотонный", "Свои обои"),
            o(WAVES, "Яркость волн", 1, "Слабые", "Обычные", "Яркие"),
            o(BGDIM, "Затемнение фона", 0, "Нет", "20%", "40%", "60%"),

            h("ЧАСЫ"),
            o(CLOCK_SHOW, "Часы", 0, "Показывать", "Скрыть"),
            o(CLOCK_FMT, "Формат времени", 0, "24 часа", "12 часов"),
            o(CLOCK_SIZE, "Размер часов", 1, "Малые", "Средние", "Крупные", "Огромные"),
            o(CLOCK_POS, "Положение часов", 0, "Слева", "По центру", "Справа"),
            o(CLOCK_FONT, "Шрифт часов", 1, "Тонкий", "Лёгкий", "Обычный", "Жирный"),
            o(CLOCK_DATE, "Дата", 0, "Показывать", "Скрыть"),

            h("ПЛИТКИ ИЗБРАННОГО"),
            o(TILE_SIZE, "Размер плиток", 1, "Мелкие", "Средние", "Крупные"),
            o(TILE_RATIO, "Пропорции", 0, "16:9", "4:3", "Квадрат"),
            o(TILE_ROUND, "Скругление углов", 2, "Острые", "Малое", "Среднее", "Большое"),
            o(TILE_GAP, "Расстояние между плитками", 1, "Малое", "Среднее", "Большое"),
            o(TILE_BANNERS, "Баннеры приложений", 0, "Показывать", "Не показывать"),
            o(TILE_LABELS, "Подписи на плитках", 0, "Показывать", "Скрыть"),
            o(TILE_TINT, "Цвет плиток без баннера", 0, "По иконке", "Тёмный", "Акцентный"),
            o(ROW_POS, "Положение ряда", 0, "Внизу", "Выше", "По центру"),
            o(ALL_POS, "Плитка «Все приложения»", 1, "В начале ряда", "В конце ряда"),

            h("ВЫДЕЛЕНИЕ"),
            o(FOCUS_SCALE, "Увеличение выбранной", 2, "Нет", "Малое", "Среднее", "Большое"),
            o(FOCUS_BORDER, "Рамка выбранной", 1, "Нет", "Белая", "Акцентная"),
            o(FOCUS_ANIM, "Скорость анимации", 1, "Быстро", "Обычно", "Плавно", "Без анимации"),

            h("СПИСОК «ВСЕ ПРИЛОЖЕНИЯ»"),
            o(ALL_COLS, "Колонок", 1, "4", "5", "6", "7"),
            o(ALL_SORT, "Сортировка", 0, "А → Я", "Я → А", "Частые сверху")
    };

    private final SharedPreferences sp;

    Cfg(Context c) {
        sp = c.getSharedPreferences("launcher_pro", Context.MODE_PRIVATE);
    }

    int get(String key) { return sp.getInt(key, defOf(key)); }

    void set(String key, int v) { sp.edit().putInt(key, v).apply(); }

    private static int defOf(String key) {
        for (Opt op : OPTS) {
            if (key.equals(op.key)) return op.def;
        }
        return 0;
    }

    boolean has(String key) { return sp.contains(key); }

    void remove(String key) { sp.edit().remove(key).apply(); }

    // Списки (избранное, скрытые приложения): пакеты через перевод строки
    List<String> list(String key) {
        String s = sp.getString(key, "");
        List<String> l = new ArrayList<String>();
        if (s != null && !s.isEmpty()) {
            for (String x : s.split("\n")) {
                if (!x.isEmpty()) l.add(x);
            }
        }
        return l;
    }

    void saveList(String key, List<String> l) {
        sp.edit().putString(key, TextUtils.join("\n", l)).apply();
    }

    // Счётчик запусков для сортировки «Частые сверху»
    int count(String pkg) { return sp.getInt("n_" + pkg, 0); }

    void inc(String pkg) { sp.edit().putInt("n_" + pkg, count(pkg) + 1).apply(); }

    void resetOptions() {
        SharedPreferences.Editor e = sp.edit();
        for (Opt op : OPTS) {
            if (!op.isHeader()) e.remove(op.key);
        }
        e.apply();
    }
}
