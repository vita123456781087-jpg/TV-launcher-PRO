package com.example.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

/** Фон главного экрана. Рисуется только при смене настроек, без анимаций. */
final class BgView extends View {

    private final Paint bgP = new Paint();
    private final Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lineP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimP = new Paint();
    private final Paint bmpP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Path[] lines = new Path[3];
    private final Path[] fills = new Path[3];
    private final Shader[] fillShaders = new Shader[3];
    private final Shader[] lineShaders = new Shader[3];

    private int[] bg = {0xFF000000, 0xFF000000, 0xFF000000};
    private int[] wave = {0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF};
    private int style = 0;      // 0 волны, 1 градиент, 2 однотонный, 3 обои
    private float mul = 1f;     // яркость волн
    private Bitmap wallpaper;
    private int dim = 0;        // затемнение обоев, %
    private int vw, vh;

    BgView(Context c) {
        super(c);
        lineP.setStyle(Paint.Style.STROKE);
    }

    void apply(int[] bg, int[] wave, int style, float mul, Bitmap wp, int dimPercent) {
        this.bg = bg;
        this.wave = wave;
        this.style = style;
        this.mul = mul;
        this.wallpaper = wp;
        this.dim = dimPercent;
        rebuild();
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        vw = w;
        vh = h;
        rebuild();
    }

    private static int clamp(int a) { return Math.max(0, Math.min(255, a)); }

    private void rebuild() {
        if (vw <= 0 || vh <= 0) return;
        bgP.setShader(new LinearGradient(0, 0, vw, vh,
                new int[]{bg[0], bg[1], bg[2]}, new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
        lineP.setStrokeWidth(Math.max(2f, vw * 0.0028f));
        dimP.setColor(Color.argb(clamp(dim * 255 / 100), 0, 0, 0));

        int fa = clamp(Math.round(0x30 * mul));
        int la1 = clamp(Math.round(0xAA * mul));
        int la2 = clamp(Math.round(0x66 * mul));

        for (int i = 0; i < 3; i++) {
            float s = vh * (0.60f + 0.075f * i);
            float e = vh * (0.30f + 0.09f * i);
            float amp = vh * 0.07f * (i % 2 == 0 ? 1 : -1);

            Path p = new Path();
            p.moveTo(0, s);
            p.cubicTo(vw * 0.30f, s + amp, vw * 0.58f, e - amp, vw, e);
            Path f = new Path(p);
            f.lineTo(vw, vh);
            f.lineTo(0, vh);
            f.close();
            lines[i] = p;
            fills[i] = f;

            int rgb = wave[i] & 0x00FFFFFF;
            fillShaders[i] = new LinearGradient(0, e, 0, vh,
                    (fa << 24) | rgb, rgb, Shader.TileMode.CLAMP);
            lineShaders[i] = new LinearGradient(0, 0, vw, 0,
                    new int[]{rgb, (la1 << 24) | rgb, (la2 << 24) | rgb},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (vw <= 0 || vh <= 0) return;

        if (style == 2) { // однотонный
            c.drawColor(bg[1]);
            return;
        }
        if (style == 3 && wallpaper != null && !wallpaper.isRecycled()) { // обои
            float s = Math.max((float) vw / wallpaper.getWidth(), (float) vh / wallpaper.getHeight());
            float dx = (vw - wallpaper.getWidth() * s) / 2f;
            float dy = (vh - wallpaper.getHeight() * s) / 2f;
            c.save();
            c.translate(dx, dy);
            c.scale(s, s);
            c.drawBitmap(wallpaper, 0, 0, bmpP);
            c.restore();
            if (dim > 0) c.drawRect(0, 0, vw, vh, dimP);
            return;
        }

        c.drawRect(0, 0, vw, vh, bgP); // градиент
        if (style == 0) { // волны
            for (int i = 0; i < 3; i++) {
                if (fills[i] == null) continue;
                fillP.setShader(fillShaders[i]);
                c.drawPath(fills[i], fillP);
                lineP.setShader(lineShaders[i]);
                c.drawPath(lines[i], lineP);
            }
        }
    }
}
