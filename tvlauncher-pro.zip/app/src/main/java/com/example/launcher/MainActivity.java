package com.example.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    // Приложения, которые сами попадут в избранное при первом запуске (если установлены)
    private static final String[] DEFAULT_FAVS = {
            "org.smarttube.stable", "org.smarttube.beta", "com.liskovsoft.smarttubetv.beta",
            "org.xbmc.kodi", "org.videolan.vlc", "com.mxtech.videoplayer.ad",
            "com.esaba.downloader", "com.android.tv.settings", "com.android.settings"
    };

    private static final int FOCUS_NONE = -1;
    private static final int FOCUS_ALL = -2;
    private static final int REQ_STORAGE = 1;
    private static final String LIST_FAVS = "favs";
    private static final String LIST_HIDDEN = "hidden";

    private static class App {
        String label;
        String pkg;
        Drawable icon;
        ActivityInfo ai;
        Intent intent;
        int color;
        boolean system;
    }

    private Cfg cfg;
    private PackageManager pm;
    private float u; // 1 условная единица = 1% ширины экрана

    private FrameLayout root;
    private FrameLayout home;
    private FrameLayout gear;
    private BgView bg;
    private LinearLayout top;
    private LinearLayout row;
    private TextClock clock;
    private TextClock date;
    private HorizontalScrollView rowScroll;
    private TextView hint;
    private LinearLayout allOverlay;
    private FrameLayout settingsOverlay;

    private final Map<String, TextView> stars = new HashMap<String, TextView>();
    private final List<App> apps = new ArrayList<App>();
    private Bitmap wallpaper;
    private String lastSig = "";
    private boolean firstStart = true;
    private volatile boolean loading = false;

    // Текущий внешний вид (читается из настроек)
    private int tileW, tileH, tileGap, borderColor, accent, tintMode, focusMs;
    private float tileRad, focusScale;
    private boolean useBanners, useLabels;

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { loadApps(); }
    };

    // ================================================================ старт

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new Cfg(this);
        pm = getPackageManager();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        u = dm.widthPixels / 100f;
        readLook();
        buildUi();
        applyRowPos();
        applyClock();
        updateBg();
        loadApps();
    }

    private int px(float units) { return Math.round(units * u); }

    private int idx(String key, int len) {
        return Math.max(0, Math.min(len - 1, cfg.get(key)));
    }

    private TextView text(String s, float sizeU, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void safeStart(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("Не удалось открыть"); }
    }

    private static int mix(int color, int base, float t) {
        int r = Math.round(Color.red(color) * t + Color.red(base) * (1 - t));
        int g = Math.round(Color.green(color) * t + Color.green(base) * (1 - t));
        int b = Math.round(Color.blue(color) * t + Color.blue(base) * (1 - t));
        return Color.rgb(r, g, b);
    }

    // Чёрный или белый текст в зависимости от яркости фона
    private static int textOn(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.72 ? 0xFF101010 : Color.WHITE;
    }

    // ================================================== чтение настроек вида

    private void readLook() {
        float[] widths = {16f, 19.5f, 23f};
        float[] ratios = {0.5625f, 0.75f, 1f};
        float[] rads = {0.2f, 0.7f, 1.1f, 2.0f};
        float[] gaps = {0.6f, 1.2f, 2.0f};
        float[] scales = {1f, 1.04f, 1.08f, 1.14f};
        int[] anims = {80, 120, 220, 0};

        tileW = px(widths[idx(Cfg.TILE_SIZE, 3)]);
        tileH = Math.round(tileW * ratios[idx(Cfg.TILE_RATIO, 3)]);
        tileRad = rads[idx(Cfg.TILE_ROUND, 4)] * u;
        tileGap = px(gaps[idx(Cfg.TILE_GAP, 3)]);
        focusScale = scales[idx(Cfg.FOCUS_SCALE, 4)];
        focusMs = anims[idx(Cfg.FOCUS_ANIM, 4)];
        accent = Cfg.ACCENTS[idx(Cfg.ACCENT, Cfg.ACCENTS.length)];

        int fb = idx(Cfg.FOCUS_BORDER, 3);
        borderColor = fb == 0 ? 0 : (fb == 1 ? 0xFFFFFFFF : accent);
        useBanners = idx(Cfg.TILE_BANNERS, 2) == 0;
        useLabels = idx(Cfg.TILE_LABELS, 2) == 0;
        tintMode = idx(Cfg.TILE_TINT, 3);
    }

    // =============================================================== главный экран

    private void buildUi() {
        root = new FrameLayout(this);
        home = new FrameLayout(this);
        root.addView(home, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bg = new BgView(this);
        home.addView(bg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Часы и дата
        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        clock = new TextClock(this);
        clock.setTextColor(Color.WHITE);
        top.addView(clock);
        date = new TextClock(this);
        date.setFormat24Hour("EEEE, d MMMM");
        date.setFormat12Hour("EEEE, d MMMM");
        date.setTextColor(0xB3FFFFFF);
        top.addView(date);
        home.addView(top, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START));

        // Ряд избранного
        rowScroll = new HorizontalScrollView(this);
        rowScroll.setHorizontalScrollBarEnabled(false);
        rowScroll.setClipChildren(false);
        rowScroll.setClipToPadding(false);
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        rowScroll.addView(row, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        home.addView(rowScroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        // Подсказка, пока избранное пустое
        hint = text("Откройте «Все приложения» и удерживайте OK на приложении, чтобы добавить его сюда",
                1.6f, 0x99FFFFFF);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        hp.leftMargin = px(5f);
        hp.bottomMargin = px(1f);
        home.addView(hint, hp);
        hint.setVisibility(View.GONE);

        // Кнопка настроек справа сверху
        int gs = px(5f);
        gear = new FrameLayout(this);
        GradientDrawable gbg = new GradientDrawable();
        gbg.setShape(GradientDrawable.OVAL);
        gbg.setColor(0x33FFFFFF);
        gear.setBackground(gbg);
        gear.addView(new Widgets.SlidersIcon(this), new FrameLayout.LayoutParams(
                px(2.6f), px(2.6f), Gravity.CENTER));
        gear.setOnClickListener(v -> openSettings());
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(gs, gs, Gravity.TOP | Gravity.END);
        gp.topMargin = px(3.5f);
        gp.rightMargin = px(3.5f);
        home.addView(gear, gp);
        decorateGear();

        setContentView(root);
    }

    private void decorateGear() { decorate(gear, px(5f) / 2f); }

    private void applyClock() {
        boolean show = idx(Cfg.CLOCK_SHOW, 2) == 0;
        top.setVisibility(show ? View.VISIBLE : View.GONE);

        String f = idx(Cfg.CLOCK_FMT, 2) == 0 ? "HH:mm" : "h:mm";
        clock.setFormat24Hour(f);
        clock.setFormat12Hour(f);

        float[] sizes = {6f, 8.5f, 11f, 14f};
        float sz = sizes[idx(Cfg.CLOCK_SIZE, 4)];
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, sz * u);
        date.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.max(1.6f, sz * 0.26f) * u);

        int ft = idx(Cfg.CLOCK_FONT, 4);
        Typeface tf;
        if (ft == 0) tf = Typeface.create("sans-serif-thin", Typeface.NORMAL);
        else if (ft == 1) tf = Typeface.create("sans-serif-light", Typeface.NORMAL);
        else if (ft == 2) tf = Typeface.create("sans-serif", Typeface.NORMAL);
        else tf = Typeface.create("sans-serif", Typeface.BOLD);
        clock.setTypeface(tf);

        date.setVisibility(idx(Cfg.CLOCK_DATE, 2) == 0 ? View.VISIBLE : View.GONE);

        int pos = idx(Cfg.CLOCK_POS, 3);
        top.setPadding(px(5f), px(3.5f), px(pos == 2 ? 11f : 5f), 0);
        top.setGravity(pos == 0 ? Gravity.START : (pos == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.END));
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) top.getLayoutParams();
        lp.gravity = Gravity.TOP | (pos == 0 ? Gravity.START
                : (pos == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.END));
        top.setLayoutParams(lp);
    }

    private void applyRowPos() {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) rowScroll.getLayoutParams();
        int pos = idx(Cfg.ROW_POS, 3);
        lp.gravity = pos == 2 ? Gravity.CENTER_VERTICAL : Gravity.BOTTOM;
        lp.bottomMargin = pos == 0 ? px(3.5f) : (pos == 1 ? px(15f) : 0);
        rowScroll.setLayoutParams(lp);
        int pad = Math.round(tileH * (focusScale - 1f) / 2f) + px(1f);
        rowScroll.setPadding(px(5f), pad, px(5f), pad);
    }

    private void applyLook() {
        readLook();
        applyRowPos();
        decorateGear();
        refreshRow(FOCUS_NONE);
    }

    private void applyAll() {
        applyLook();
        applyClock();
        updateBg();
    }

    private LinearLayout.LayoutParams tileLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(tileW, tileH);
        lp.rightMargin = tileGap;
        return lp;
    }

    private void refreshRow(int focusIdx) {
        row.removeAllViews();
        boolean allFirst = idx(Cfg.ALL_POS, 2) == 0;
        if (allFirst) row.addView(makeAllTile(), tileLp());

        int favCount = 0;
        for (String pkg : cfg.list(LIST_FAVS)) {
            final App a = find(pkg);
            if (a == null) continue;
            favCount++;
            View t = tile(a, tileW, tileH, useBanners);
            t.setTag(a.pkg);
            t.setOnClickListener(v -> launch(a));
            t.setOnLongClickListener(v -> { showAppMenu(a); return true; });
            row.addView(t, tileLp());
        }

        if (!allFirst) row.addView(makeAllTile(), tileLp());
        hint.setVisibility(favCount == 0 ? View.VISIBLE : View.GONE);

        if (focusIdx != FOCUS_NONE && allOverlay == null && settingsOverlay == null) {
            int count = row.getChildCount();
            int i = focusIdx == FOCUS_ALL ? (allFirst ? 0 : count - 1) : Math.min(focusIdx, count - 1);
            View fv = row.getChildAt(i);
            if (fv != null) fv.requestFocus();
        }
    }

    private void focusTile(String pkg) {
        for (int i = 0; i < row.getChildCount(); i++) {
            View c = row.getChildAt(i);
            if (pkg.equals(c.getTag())) { c.requestFocus(); return; }
        }
    }

    // Плитка приложения: баннер (если есть) или иконка на цветном фоне
    private FrameLayout tile(App a, int w, int h, boolean wantBanner) {
        FrameLayout f = new FrameLayout(this);

        Drawable banner = null;
        if (wantBanner) {
            try { banner = a.ai.loadBanner(pm); } catch (Throwable ignored) { }
        }

        if (banner != null) {
            f.setBackgroundColor(0xFF10162A);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageDrawable(banner);
            f.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            int base = tintMode == 0 ? a.color : (tintMode == 1 ? 0xFF3A4156 : accent);
            GradientDrawable grad = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{mix(base, 0xFF141A2B, 0.55f), mix(base, 0xFF0B1020, 0.18f)});
            grad.setCornerRadius(tileRad);
            f.setBackground(grad);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            col.setPadding(px(0.8f), 0, px(0.8f), 0);

            int is = Math.round(h * (useLabels ? 0.44f : 0.58f));
            ImageView icon = new ImageView(this);
            icon.setImageDrawable(a.icon);
            col.addView(icon, new LinearLayout.LayoutParams(is, is));

            if (useLabels) {
                TextView lb = new TextView(this);
                lb.setText(a.label);
                lb.setTextColor(Color.WHITE);
                lb.setTextSize(TypedValue.COMPLEX_UNIT_PX, h * 0.13f);
                lb.setSingleLine(true);
                lb.setEllipsize(TextUtils.TruncateAt.END);
                lb.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.topMargin = Math.round(h * 0.06f);
                col.addView(lb, lp);
            }
            f.addView(col, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        decorate(f, tileRad);
        return f;
    }

    // Плитка «Все приложения»
    private FrameLayout makeAllTile() {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable grad = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{accent, mix(accent, 0xFF000000, 0.45f)});
        grad.setCornerRadius(tileRad);
        f.setBackground(grad);

        int fg = textOn(accent);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int is = Math.round(tileH * 0.36f);
        col.addView(new Widgets.GridIcon(this, fg), new LinearLayout.LayoutParams(is, is));

        TextView lb = new TextView(this);
        lb.setText("Все приложения");
        lb.setTextColor(fg);
        lb.setTextSize(TypedValue.COMPLEX_UNIT_PX, tileH * 0.13f);
        lb.setSingleLine(true);
        lb.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Math.round(tileH * 0.07f);
        col.addView(lb, lp);

        f.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        decorate(f, tileRad);
        f.setOnClickListener(v -> openAll());
        f.setOnLongClickListener(v -> { openSettings(); return true; });
        return f;
    }

    // Скругление, рамка выбора и увеличение при фокусе
    private void decorate(FrameLayout f, final float rad) {
        f.setFocusable(true);
        f.setClickable(true);
        f.setLongClickable(true);
        f.setClipToOutline(true);
        f.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
            }
        });

        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(Color.TRANSPARENT);
        on.setCornerRadius(rad);
        if (borderColor != 0) on.setStroke(Math.max(2, Math.round(0.3f * u)), borderColor);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        f.setForeground(sl);

        f.setOnFocusChangeListener((v, has) -> {
            float s = has ? focusScale : 1f;
            v.animate().scaleX(s).scaleY(s).setDuration(focusMs).start();
            v.setTranslationZ(has ? u * 0.8f : 0f);
        });
    }

    // =================================================================== фон

    private void updateBg() {
        int th = idx(Cfg.THEME, Cfg.THEME_BG.length);
        int st = idx(Cfg.BGSTYLE, 4);
        float[] muls = {0.5f, 1f, 1.6f};
        int[] dims = {0, 20, 40, 60};
        if (st == 3 && wallpaper == null) ensureWallpaper(false);
        bg.apply(Cfg.THEME_BG[th], Cfg.THEME_WAVE[th], st, muls[idx(Cfg.WAVES, 3)],
                st == 3 ? wallpaper : null, dims[idx(Cfg.BGDIM, 4)]);
    }

    // Обои берутся из файла Download/launcher_bg.jpg (или .png)
    private void ensureWallpaper(boolean userAction) {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (userAction) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
            }
            return;
        }
        loadWallpaper();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_STORAGE) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            loadWallpaper();
        } else {
            toast("Нет доступа к файлам. Разрешите в Настройки → Приложения → Лаунчер → Разрешения");
        }
    }

    private void loadWallpaper() {
        final int sw = getResources().getDisplayMetrics().widthPixels;
        final int sh = getResources().getDisplayMetrics().heightPixels;
        new Thread(new Runnable() {
            @Override public void run() {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File[] cands = {
                        new File(dir, "launcher_bg.jpg"),
                        new File(dir, "launcher_bg.png"),
                        new File(Environment.getExternalStorageDirectory(), "launcher_bg.jpg")
                };
                Bitmap bmp = null;
                for (File f : cands) {
                    if (!f.exists()) continue;
                    try {
                        BitmapFactory.Options o = new BitmapFactory.Options();
                        o.inJustDecodeBounds = true;
                        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                        int sample = 1;
                        while (o.outWidth / (sample * 2) >= sw && o.outHeight / (sample * 2) >= sh) {
                            sample *= 2;
                        }
                        o.inJustDecodeBounds = false;
                        o.inSampleSize = sample;
                        o.inPreferredConfig = Bitmap.Config.RGB_565;
                        bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    } catch (Throwable ignored) { }
                    if (bmp != null) break;
                }
                final Bitmap result = bmp;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (result == null) {
                            toast("Файл не найден: положите launcher_bg.jpg в папку Download");
                            return;
                        }
                        Bitmap old = wallpaper;
                        wallpaper = result;
                        updateBg();
                        if (old != null) old.recycle();
                    }
                });
            }
        }).start();
    }

    // ============================================================ избранное

    private boolean isFav(String pkg) { return cfg.list(LIST_FAVS).contains(pkg); }

    private boolean toggleFav(App a) {
        List<String> l = cfg.list(LIST_FAVS);
        boolean now;
        if (l.contains(a.pkg)) { l.remove(a.pkg); now = false; }
        else { l.add(a.pkg); now = true; }
        cfg.saveList(LIST_FAVS, l);
        return now;
    }

    private void onFavChanged(App a) {
        refreshRow(FOCUS_NONE);
        TextView st = stars.get(a.pkg);
        if (st != null) st.setVisibility(isFav(a.pkg) ? View.VISIBLE : View.GONE);
        toast(isFav(a.pkg) ? "Добавлено в избранное: " + a.label
                           : "Убрано из избранного: " + a.label);
    }

    private void moveFav(App a, int dir) {
        List<String> l = cfg.list(LIST_FAVS);
        int i = l.indexOf(a.pkg);
        int j = i + dir;
        if (i < 0 || j < 0 || j >= l.size()) { toast("Дальше нельзя"); return; }
        Collections.swap(l, i, j);
        cfg.saveList(LIST_FAVS, l);
        refreshRow(FOCUS_NONE);
        focusTile(a.pkg);
    }

    private void hideApp(App a) {
        List<String> hidden = cfg.list(LIST_HIDDEN);
        if (!hidden.contains(a.pkg)) hidden.add(a.pkg);
        cfg.saveList(LIST_HIDDEN, hidden);
        List<String> favs = cfg.list(LIST_FAVS);
        favs.remove(a.pkg);
        cfg.saveList(LIST_FAVS, favs);
        toast("Скрыто: " + a.label + " (вернуть: Настройки → Показать скрытые)");
        refreshRow(FOCUS_NONE);
        if (allOverlay != null) {
            closeAll(false);
            openAll();
        }
    }

    private void fillDefaultFavs() {
        List<String> favs = new ArrayList<String>();
        for (String p : DEFAULT_FAVS) {
            if (find(p) != null) favs.add(p);
        }
        cfg.saveList(LIST_FAVS, favs);
    }

    private App find(String pkg) {
        for (App a : apps) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    private void launch(App a) {
        cfg.inc(a.pkg);
        try { startActivity(a.intent); }
        catch (Exception e) { toast("Не удалось открыть " + a.label); }
    }

    // Меню по долгому нажатию OK на приложении
    private void showAppMenu(final App a) {
        final boolean fav = isFav(a.pkg);
        final List<String> names = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();

        names.add(fav ? "Убрать из избранного" : "Добавить в избранное");
        acts.add(() -> { toggleFav(a); onFavChanged(a); });

        if (fav) {
            names.add("Сдвинуть влево");
            acts.add(() -> moveFav(a, -1));
            names.add("Сдвинуть вправо");
            acts.add(() -> moveFav(a, 1));
        }

        names.add("Скрыть из списка");
        acts.add(() -> hideApp(a));

        names.add("О приложении");
        acts.add(() -> safeStart(new Intent(
                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.pkg))));

        if (!a.system) {
            names.add("Удалить");
            acts.add(() -> safeStart(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))));
        }

        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(a.label)
                .setItems(names.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void confirm(String msg, final Runnable yes) {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setMessage(msg)
                .setPositiveButton("Да", (d, w) -> yes.run())
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ========================================================= все приложения

    private void openAll() {
        if (allOverlay != null || settingsOverlay != null) return;

        List<App> list = new ArrayList<App>();
        List<String> hidden = cfg.list(LIST_HIDDEN);
        for (App a : apps) {
            if (!hidden.contains(a.pkg)) list.add(a);
        }
        int sort = idx(Cfg.ALL_SORT, 3);
        if (sort == 1) {
            Collections.reverse(list);
        } else if (sort == 2) {
            Collections.sort(list, new Comparator<App>() {
                @Override public int compare(App x, App y) {
                    int c = cfg.count(y.pkg) - cfg.count(x.pkg);
                    return c != 0 ? c : x.label.compareToIgnoreCase(y.label);
                }
            });
        }

        int th = idx(Cfg.THEME, Cfg.THEME_BG.length);
        allOverlay = new LinearLayout(this);
        allOverlay.setOrientation(LinearLayout.VERTICAL);
        allOverlay.setBackgroundColor((0xF0 << 24) | (Cfg.THEME_BG[th][0] & 0x00FFFFFF));
        allOverlay.setClickable(true);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(px(5f), px(3f), px(5f), px(1f));
        head.addView(text("Все приложения · " + list.size(), 3.4f, Color.WHITE));
        head.addView(text("Удерживайте OK на приложении — меню (избранное, скрыть, удалить)",
                1.5f, 0x99FFFFFF));
        allOverlay.addView(head, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipChildren(false);
        sv.setClipToPadding(false);
        sv.setPadding(px(4.4f), px(1.5f), px(4.4f), px(3f));

        int cols = 4 + idx(Cfg.ALL_COLS, 4);
        GridLayout gl = new GridLayout(this);
        gl.setColumnCount(cols);
        gl.setClipChildren(false);

        int cw = px((100f - 8.8f - cols * 1.2f) / cols);
        int ch = Math.round(cw * 0.62f);
        int m = px(0.6f);
        stars.clear();

        for (final App a : list) {
            FrameLayout t = tile(a, cw, ch, false);
            TextView star = text("★", 2.2f, 0xFFFFD54F);
            FrameLayout.LayoutParams sp2 = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.END);
            sp2.setMargins(0, px(0.4f), px(0.8f), 0);
            t.addView(star, sp2);
            star.setVisibility(isFav(a.pkg) ? View.VISIBLE : View.GONE);
            stars.put(a.pkg, star);

            t.setOnClickListener(v -> launch(a));
            t.setOnLongClickListener(v -> { showAppMenu(a); return true; });

            GridLayout.LayoutParams glp = new GridLayout.LayoutParams();
            glp.width = cw;
            glp.height = ch;
            glp.setMargins(m, m, m, m);
            gl.addView(t, glp);
        }

        sv.addView(gl, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        allOverlay.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(allOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        home.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (gl.getChildCount() > 0) gl.getChildAt(0).requestFocus();
    }

    private void closeAll(boolean focusRow) {
        if (allOverlay == null) return;
        root.removeView(allOverlay);
        allOverlay = null; // освобождаем память
        stars.clear();
        home.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (focusRow) refreshRow(FOCUS_ALL);
    }

    // ============================================================= настройки

    private Drawable rowBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(0x33FFFFFF);
        on.setCornerRadius(0.8f * u);
        on.setStroke(Math.max(2, Math.round(0.2f * u)), accent);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return sl;
    }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = px(0.3f);
        return lp;
    }

    private void openSettings() {
        if (settingsOverlay != null || allOverlay != null) return;
        settingsOverlay = new FrameLayout(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xF2101624);
        panel.setPadding(px(2f), px(2.5f), px(1.5f), px(1f));
        panel.addView(text("Настройки", 3f, Color.WHITE));
        panel.addView(text("← → меняют значение, OK — следующее, Назад — закрыть", 1.3f, 0x99FFFFFF));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setPadding(0, px(1f), px(0.5f), px(2f));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        View firstRow = null;
        for (Cfg.Opt o : Cfg.OPTS) {
            if (o.isHeader()) {
                list.addView(sectionTitle(o.title));
            } else {
                View r = optRow(o);
                if (firstRow == null) firstRow = r;
                list.addView(r, rowLp());
            }
        }

        list.addView(sectionTitle("ДАННЫЕ"));
        list.addView(actionRow("Сбросить избранное к стандартному", () -> confirm(
                "Сбросить избранное к стандартному набору?", () -> {
                    cfg.remove(LIST_FAVS);
                    fillDefaultFavs();
                    refreshRow(FOCUS_NONE);
                    toast("Избранное сброшено");
                })), rowLp());
        list.addView(actionRow("Показать скрытые приложения", () -> {
            cfg.remove(LIST_HIDDEN);
            toast("Скрытые приложения возвращены");
        }), rowLp());
        list.addView(actionRow("Сбросить все настройки вида", () -> confirm(
                "Вернуть стандартные настройки вида?", () -> {
                    cfg.resetOptions();
                    applyAll();
                    closeSettings(false);
                    openSettings();
                })), rowLp());

        sv.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        settingsOverlay.addView(panel, new FrameLayout.LayoutParams(
                px(42f), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));
        root.addView(settingsOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        home.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        if (firstRow != null) firstRow.requestFocus();
    }

    private void closeSettings(boolean focusRow) {
        if (settingsOverlay == null) return;
        root.removeView(settingsOverlay);
        settingsOverlay = null;
        home.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        if (focusRow) refreshRow(FOCUS_ALL);
    }

    private TextView sectionTitle(String s) {
        TextView hd = text(s, 1.4f, accent);
        hd.setPadding(px(0.5f), px(1.6f), 0, px(0.4f));
        return hd;
    }

    private View actionRow(String title, final Runnable action) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));
        r.addView(text(title, 1.8f, Color.WHITE));
        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> action.run());
        return r;
    }

    private View optRow(final Cfg.Opt o) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));

        TextView t = text(o.title, 1.8f, Color.WHITE);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text("", 1.8f, accent);
        r.addView(val);
        setValueText(val, o);

        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> changeOpt(o, val, 1));
        r.setOnKeyListener((x, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) { changeOpt(o, val, 1); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { changeOpt(o, val, -1); return true; }
            return false;
        });
        return r;
    }

    private void setValueText(TextView val, Cfg.Opt o) {
        val.setText("‹ " + o.labels[idx(o.key, o.labels.length)] + " ›");
    }

    private void changeOpt(Cfg.Opt o, TextView val, int dir) {
        int n = o.labels.length;
        int next = (idx(o.key, n) + dir + n) % n;
        cfg.set(o.key, next);
        setValueText(val, o);
        onOptChanged(o.key, next);
    }

    // Применить изменение сразу (за панелью настроек видно результат)
    private void onOptChanged(String key, int value) {
        if (key.startsWith("clock_")) {
            applyClock();
        } else if (key.equals(Cfg.THEME) || key.startsWith("bg_")) {
            if (key.equals(Cfg.BGSTYLE) && value == 3 && wallpaper == null) ensureWallpaper(true);
            updateBg();
        } else if (key.startsWith("all_") || key.equals(Cfg.ALL_COLS) || key.equals(Cfg.ALL_SORT)) {
            // применится при следующем открытии списка
        } else {
            applyLook();
        }
    }

    // ============================================= загрузка списка приложений

    private void loadApps() {
        if (loading) return;
        loading = true;
        new Thread(new Runnable() {
            @Override public void run() {
                final List<App> result = queryApps();
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        loading = false;
                        StringBuilder sb = new StringBuilder();
                        for (App a : result) sb.append(a.pkg).append('|').append(a.label).append(';');
                        String sig = sb.toString();
                        if (sig.equals(lastSig)) return; // ничего не изменилось
                        boolean initial = lastSig.isEmpty();
                        lastSig = sig;
                        apps.clear();
                        apps.addAll(result);

                        if (!cfg.has(LIST_FAVS)) fillDefaultFavs(); // первый запуск
                        if (allOverlay == null && settingsOverlay == null) {
                            refreshRow(initial ? 0 : FOCUS_NONE);
                        }
                    }
                });
            }
        }).start();
    }

    private List<App> queryApps() {
        List<App> out = new ArrayList<App>();
        Set<String> seen = new HashSet<String>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};

        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.ai = ri.activityInfo;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.icon = ri.loadIcon(pm);
                a.color = dominant(a.icon);
                a.system = (ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                a.intent = new Intent(Intent.ACTION_MAIN)
                        .addCategory(cat)
                        .setComponent(new ComponentName(pkg, ri.activityInfo.name))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                out.add(a);
            }
        }
        final Collator col = Collator.getInstance();
        Collections.sort(out, new Comparator<App>() {
            @Override public int compare(App x, App y) { return col.compare(x.label, y.label); }
        });
        return out;
    }

    // Средний цвет иконки (для подкраски плитки)
    private static int dominant(Drawable d) {
        final int fallback = 0xFF2A3350;
        try {
            Drawable.ConstantState cs = d.getConstantState();
            Drawable c = (cs != null) ? cs.newDrawable().mutate() : d;
            Bitmap b = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            c.setBounds(0, 0, 16, 16);
            c.draw(cv);
            long r = 0, g = 0, bl = 0, n = 0;
            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 16; x++) {
                    int p = b.getPixel(x, y);
                    if (Color.alpha(p) < 128) continue;
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                    n++;
                }
            }
            b.recycle();
            if (n == 0) return fallback;
            return Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n));
        } catch (Throwable t) {
            return fallback;
        }
    }

    // ========================================================= жизненный цикл

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);
        if (!firstStart) loadApps(); // вернулись на главный экран: проверим список
        firstStart = false;
    }

    @Override
    protected void onStop() {
        super.onStop();
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) { }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Нажатие Home: закрыть списки и вернуться в начало ряда
        closeSettings(false);
        closeAll(false);
        rowScroll.scrollTo(0, 0);
        if (row.getChildCount() > 0) row.getChildAt(0).requestFocus();
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) { // кнопка меню на пульте
            openSettings();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (settingsOverlay != null) closeSettings(true);
        else if (allOverlay != null) closeAll(true);
        // на главном экране «Назад» ничего не делает
    }
}
